# Brigade Barcelona

A local, browser-based architectural sales experience for Plot 20, Neopolis, Kokapet. Start above the neighborhood, orbit the connected wings, choose a brochure floor and design, then enter the furnished Wing A, Unit 3 concept. The app serves its models, photographs, maps, fonts and decoders locally.

## Run

From the repository root, run the static server with Python 3.

```sh
python3 -m http.server 5173 --bind 127.0.0.1 --directory dist
```

Open the [buyer experience](http://127.0.0.1:5173/) or the [project studio](http://127.0.0.1:5173/admin/). The checked-in application runs without a build step or API keys. The studio opens a browser-local authoring workspace by default. Connected production workflows require the Supabase configuration described below.

## Explore

- Drag or pinch the exterior to change the view. The cinematic introduction can be skipped, replayed or interrupted by a drag. Reduced motion uses immediate viewpoints.
- Open **Towers**, choose a wing and click a documented floor on the facade or in the panel. The source plates cover floor 12 and floors 17–20 and 22–26. The refuge floor replaces A7 with a terrace.
- Open **Apartments** to inspect all 13 source designs, including 3 BHK, 3 BHK with study and 4 BHK. Compare brochure figures, save designs on this device and enlarge individual source plans.
- Use **Explore apartment in 3D** on A3 for the furnished walkthrough. Use the room thumbnails, plan regions, keyboard or touch controls to travel. The source plan shows the current position and direction. The deck offers a labelled geographic view simulation.
- **Amenities** visits the clubhouse, gardens and rooftop sky deck. **Location** explores mapped landmarks. The exterior and interior each support daylight and evening.
- **Enquire** downloads a design-specific draft in standalone mode. A configured sales connection enables consent-based submission. Optional visit analytics require consent.
- Example links include the [refuge floor](http://127.0.0.1:5173/?scene=towers&wing=A&floor=12), a [four-bedroom design](http://127.0.0.1:5173/?scene=apartments&wing=B&design=B10) and the [A3 kitchen](http://127.0.0.1:5173/?view=walk&room=kitchen).

## Architectural basis

The 26-page developer brochure supplies the connected wing arrangement, floor plates, design areas and amenity references. Plot 20 is registered against the 16 published HMDA parcel vertices. Four control points fit the brochure masterplan to the survey with 1.03 m RMS residual. The tower setting-out, floor elevations, façade details, furniture, finishes, daylight and balcony outlook are concept reconstructions. The supplied sales site and brochure give different storey counts. The demonstration follows the brochure and limits floor selection to its documented plates.

The neighborhood includes mapped roads, approximate building volumes, sampled elevation and a March 2025 Sentinel-2 terrain image. The airborne camera and lighting convey the proposed development. Approved construction drawings, actual unit inventory, verified prices and apartment-specific view studies remain separate inputs.

The reference recording shows an aerial selection, a persistent apartment sheet and a cut into a furnished room with thumbnail navigation. The local build follows that interaction sequence with a continuous 3D camera transition. The ConnectLabs URL did not return a reviewable page during the source audit.

[Architectural asset manifest](dist/assets/architectural-manifest.json) · [Registration check](qa/parcel-registration.json) · [Geographic credits](dist/assets/geography/CREDITS.txt) · [Atmospheric lighting credit](dist/assets/sky-light.LICENSE.txt)

## Source and operations

| Deliverable | Location |
| --- | --- |
| Buyer interface, exterior camera, picking and materials | [dist](dist/), [estate-scene.js](dist/estate-scene.js), [estate.js](dist/estate.js) |
| Masterplan, two exterior detail levels and neighborhood | [assets](dist/assets/), [Blender masterplan](models/masterplan.blend), [rebuild instructions](models/README.md) |
| Furnished A3, KTX2 textures and baked indirect light | [Blender apartment](models/apartment-a3.blend), [optimized GLB](dist/assets/apartment-a3-web.glb), [authoring instructions](docs/apartment-authoring.md) |
| Tenant-aware schema, policies, publication and rollback | [Supabase setup](supabase/README.md), [migrations](supabase/migrations/), [rollback](supabase/rollback/) |
| Authoring, frozen review previews, sales and engagement | [Project studio](dist/admin/), [release collection](dist/release-library.js) |
| Release preparation and measured performance | [Deployment guide](docs/deployment.md), [verification report](docs/verification.md), [raw results](qa/) |
