# Architectural model sources

Open `masterplan.blend` in Blender 4.3 or later. The named wing, podium, planted terrace and neighborhood groups contain the editable geometry. The two wing storey modules and trees use linked meshes. `apartment-a3.blend` contains the separate furnished home.

## Rebuild the masterplan

Run from the project root. The sources bundled under `dist/assets` are sufficient for an offline rebuild. Blender 4.3.2 and gltfpack 1.0 produced the delivered GLBs.

```sh
GLTFPACK=/path/to/gltfpack blender -b --python-exit-code 1 --python scripts/generate_exterior.py
```

The command writes `models/masterplan.blend`, the detailed and mobile exterior GLBs and the geographic context GLB. Setting `GLTFPACK` enables quantization and meshopt compression. The Three.js loader uses the vendored meshopt decoder. Both exterior files retain parent wing identifiers and identical wing bounds. The mobile model uses simplified windows and foliage.

## Sources and calibration

The [architectural manifest](../dist/assets/architectural-manifest.json) records the reviewed brochure version, pages, sources and limitations. The [scene map](../dist/assets/scene-map.json) contains the extracted modular bay rectangles and camera anchors. Coordinates are in metres, with Y up and +Z facing the conceptual entrance. The [HMDA Plot 20 coordinate table](https://www.hmda.gov.in/wp-content/uploads/2020/07/HMDA_Neopolis_Phase-III.pdf) on PDF page 22 supplies sixteen parcel vertices. Run `python scripts/register_plot.py` to fit four distinct brochure corners to the polygon before rebuilding DEM and imagery. This rigid registration has a 1.033 m RMS residual and preserves the authored bay dimensions. The separate geodata folder supplies the clipped ODbL database, elevation samples, Sentinel image and attribution.

To rebuild the geographic extracts, obtain the listed OpenStreetMap bbox and the four Terrarium source PNGs from the manifest. Name the PNGs `brigade-dem-X-Y.png`, replacing X and Y with their slippy tile coordinates. Then run `python scripts/prepare_neighborhood.py local-map.osm path/to/tiles` with Shapely 2 and Pillow. Terrain is sampled on a 40 m grid. A feathered pad levels the conceptual property. The area-to-height rule for surrounding buildings is an approximation.

Run `python scripts/extract_brochure_plans.py /path/to/developer-brochure.pdf` with PyMuPDF and Pillow to recreate the thirteen source design sheets and two sample floor plates. The script checks the brochure SHA-256 against the reviewed version. The developer retains rights in its original marketing artwork.

## Geometry acceptance

The [browser measurements](../qa/exterior-geometry.json) record live GPU rendering, compressed byte sizes, wing extents, instancing, draw calls and visible triangles for each final model. Budget before shadows and UI is 510,000 triangles / 85 draw calls for the detailed exterior, 80,000 / 55 for the mobile exterior and 70,000 / 10 for the surroundings. Each compressed package has a 0.5 MiB transfer budget. These measures concern this scene and camera configuration. Physical-device frame pacing and the architectural setting-out of the tower within the surveyed plot require separate checks.
